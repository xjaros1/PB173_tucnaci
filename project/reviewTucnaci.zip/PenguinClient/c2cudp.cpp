#include "c2cudp.h"
/*
namespace PenguinClient
{
C2CUdpListen::C2CUdpListen(qintptr ID, QObject *parent)
{
}


C2CUdpWrite::C2CUdpWrite()
{
}

}
*/
