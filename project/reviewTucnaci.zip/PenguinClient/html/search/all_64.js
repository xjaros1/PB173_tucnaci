var searchData=
[
  ['disconnected',['disconnected',['../classPenguinClient_1_1ClientServerThread.html#aa7ec5ef2fe7b46a75f6e36981ed0853f',1,'PenguinClient::ClientServerThread']]],
  ['displayclientlist',['displayClientList',['../classPenguinClient_1_1ClientBackgroundManager.html#a20188400ab079c3e9007f0fa8eb3eb72',1,'PenguinClient::ClientBackgroundManager']]],
  ['displayerror',['displayError',['../classPenguinClient_1_1ClientBackgroundManager.html#a60a97bd6e105887a188ca99d69996e48',1,'PenguinClient::ClientBackgroundManager']]]
];
