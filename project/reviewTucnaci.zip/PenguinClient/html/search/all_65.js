var searchData=
[
  ['endofcall',['endOfCall',['../classPenguinClient_1_1ClientServerThread.html#acb0bacb6fc830edb2ea2d7e1a33b7256',1,'PenguinClient::ClientServerThread']]],
  ['error',['error',['../classPenguinClient_1_1ClientServerThread.html#a9946be2e2851f3e87a17fbaa6da55c4f',1,'PenguinClient::ClientServerThread']]]
];
