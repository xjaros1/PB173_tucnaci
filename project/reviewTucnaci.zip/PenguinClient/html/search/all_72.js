var searchData=
[
  ['readyread',['readyRead',['../classPenguinClient_1_1ClientServerThread.html#adcb5c4f0a262e466c7112b6936bf1afa',1,'PenguinClient::ClientServerThread']]]
];
