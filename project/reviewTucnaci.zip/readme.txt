Server je k nalezeni ve slozce PenguinServer
Client je k nalezeni ve slozce PenguinClient

Trida MessageEnvelop je sdilenou tridou mezi obemi projekty, a proto je
takto mimo oba dva, aby se zmeny propagovaly bez potreby kopirovat a podobne.

AES v CTR modu ani smysluplny vystup profileru v tomto souboru neni, ve slozce prof
jsou k nalezeni vystupy a obrazky, ktere jedine se nam podarilo vydolovat z gprof/lprof.

S pozdravem Tucnaci

