var searchData=
[
  ['init',['init',['../classPenguinServer_1_1ConnectedClient.html#a89d4ee61c9736341d640b2d7edafae3b',1,'PenguinServer::ConnectedClient']]]
];
