var searchData=
[
  ['getipaddr',['getIpAddr',['../classPenguinServer_1_1ConnectedClient.html#aecc94c3bcb3bee9740d10173eb73160c',1,'PenguinServer::ConnectedClient']]],
  ['getname',['getName',['../classPenguinServer_1_1ConnectedClient.html#afd5c19ed689f899e464eed48a6e80038',1,'PenguinServer::ConnectedClient']]],
  ['getport',['getPort',['../classPenguinServer_1_1ConnectedClient.html#ad263530695c1806cbbb0070fce6552d9',1,'PenguinServer::ConnectedClient']]]
];
