var searchData=
[
  ['denyconnection',['denyConnection',['../classPenguinServer_1_1ConnectedClient.html#a10f32c661b8146c904b111aa347f37cb',1,'PenguinServer::ConnectedClient']]],
  ['disconnected',['disconnected',['../classPenguinServer_1_1ServerThread.html#ab8cf109db69f19384009aa826a35a0d8',1,'PenguinServer::ServerThread']]],
  ['distributeclients',['distributeClients',['../classPenguinServer_1_1ServerThread.html#a5505bcb3b0bb4483859c59c38636585c',1,'PenguinServer::ServerThread']]]
];
