var searchData=
[
  ['addclient',['addClient',['../classPenguinServer_1_1SharedList.html#ab64f1d39eaaea4fcf299364a7e535270',1,'PenguinServer::SharedList']]],
  ['allowconnection',['allowConnection',['../classPenguinServer_1_1ConnectedClient.html#acec0bf4652332010b498ca5cfcc29627',1,'PenguinServer::ConnectedClient']]],
  ['asknewconnection',['askNewConnection',['../classPenguinServer_1_1ServerThread.html#a7f1c00042c85effe5d3e60b102d154ec',1,'PenguinServer::ServerThread']]]
];
