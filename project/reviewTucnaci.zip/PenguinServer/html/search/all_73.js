var searchData=
[
  ['sendlist',['sendList',['../classPenguinServer_1_1ConnectedClient.html#ae14d3b2ae3096c527ba387c8b204af40',1,'PenguinServer::ConnectedClient']]],
  ['sendupdatedlist',['sendUpdatedList',['../classPenguinServer_1_1ConnectedClient.html#a9040ba0b51fb32e9bf8736aaa6e59b4d',1,'PenguinServer::ConnectedClient']]],
  ['serverlistener',['ServerListener',['../classPenguinServer_1_1ServerListener.html',1,'PenguinServer']]],
  ['serverlistener',['ServerListener',['../classPenguinServer_1_1ServerListener.html#a50619f2b21ddf6a4b6d534f984be2323',1,'PenguinServer::ServerListener']]],
  ['serverthread',['ServerThread',['../classPenguinServer_1_1ServerThread.html',1,'PenguinServer']]],
  ['serverthread',['ServerThread',['../classPenguinServer_1_1ServerThread.html#a6cab741c43bc6d0794b019115d7a1b51',1,'PenguinServer::ServerThread']]],
  ['setlist',['setList',['../classPenguinServer_1_1ClientsManager.html#ad2450664a05868d6581534a3994acfe2',1,'PenguinServer::ClientsManager']]],
  ['sharedlist',['SharedList',['../classPenguinServer_1_1SharedList.html#a228585856adff620e9824e05136f1a65',1,'PenguinServer::SharedList']]],
  ['sharedlist',['SharedList',['../classPenguinServer_1_1SharedList.html',1,'PenguinServer']]]
];
